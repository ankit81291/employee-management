module.exports = function(app){
  require('./locations')(app);
};